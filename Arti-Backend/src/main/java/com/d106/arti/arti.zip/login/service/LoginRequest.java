package com.d106.arti.login.service;

import lombok.Getter;

@Getter
public class LoginRequest {

    private String email;
    private String password;
}
