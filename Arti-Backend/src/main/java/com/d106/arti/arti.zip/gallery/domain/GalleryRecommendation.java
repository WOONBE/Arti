package com.d106.arti.gallery.domain;
// 로직 완성 후 추가 해야함.
public class GalleryRecommendation {
}
